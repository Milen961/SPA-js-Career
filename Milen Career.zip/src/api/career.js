import {del, get, post, put} from "./api.js"

export async function getAllJobs(){
    return get('/data/offers?sortBy=_createdOn%20desc')
}
